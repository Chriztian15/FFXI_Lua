-- Addon Name: AdvancedMacroSetSwitcher
-- Author: Lua Crafter
-- Description: Switches to a specified macro book and page on command

_addon.name = 'AdvancedMacroSetSwitcher'
_addon.author = 'Chriztian'
_addon.version = '1.0'
_addon.commands = {'macroset', 'ms'}

-- Event handler for addon commands
windower.register_event('addon command', function(...)
    local args = {...}
    if args[1] and tonumber(args[1]) then
        local macrobook_number = tonumber(args[1])
        local macropage_number = args[2] and tonumber(args[2]) or 1
        windower.send_command('input /macro book ' .. macrobook_number .. '; wait 0.5; input /macro set ' .. macropage_number)
        print('Switching to Macro Book ' .. macrobook_number .. ', Page ' .. macropage_number .. '.')
    else
        print('Invalid command. Use: //macroset <book number> [page number] or //ms <book number> [page number]')
    end
end)

-- Initialization message
windower.add_to_chat(207, 'AdvancedMacroSetSwitcher Loaded: Use //macroset <book number> [page number] or //ms <book number> [page number] to switch to a specific Macro Book and Page')
