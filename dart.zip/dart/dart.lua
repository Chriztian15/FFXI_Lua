_addon.name = 'Dart'
_addon.author = 'Chriztian'
_addon.version = '1.0'
_addon.commands = {'dart'}

require('logger')
require('coroutine')
extdata = require('extdata')
res_bags = require('resources').bags

local dart_id = 17307 -- Item ID for Dart
local dart_info = {id=dart_id, slot=3} -- Ammo slot is 3

function equip_and_use_dart()
    if windower.ffxi.get_player().status > 1 then
        log('You cannot use items at this time.')
        return
    end

    local item_array = {}
    local get_items = windower.ffxi.get_items
    local set_equip = windower.ffxi.set_equip

    for bag_id in pairs(res_bags:equippable(true)) do
        local bag = get_items(bag_id)
        for index, item in ipairs(bag) do
            if item.id == dart_id then
                item_array[item.id] = item
                item_array[item.id].bag = bag_id
                break
            end
        end
    end

    local item = item_array[dart_id]
    if item then
        set_equip(item.slot, dart_info.slot, item.bag)
        log('Equipping Dart. Using in 1 second.')
        coroutine.sleep(0)
        windower.chat.input('/ra <t>')
        log('Dart used.')
    else
        log('Dart not found.')
    end
end

windower.register_event('addon command', function(...)
    equip_and_use_dart()
end)
