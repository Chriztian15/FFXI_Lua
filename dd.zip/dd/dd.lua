--[[
Addon Name: DD
Version: 1.0
Author: Chriztian

Description:
This addon listens for the chat log message indicating that the "Defense Down" effect has worn off
and sends a notification to the party chat.

Loading the Addon:
- To load the addon, type the following command in the game:
  //lua load dd

Enabling/Disabling the Addon:
- The addon is enabled by default when loaded.
- To toggle (enable/disable) the addon, type the following command in the game:
  //dd
  This will switch the addon between active and inactive states.

Incorporating into a Macro:
- You can also control this addon via in-game macros. Here's how you can create macros to enable and disable the addon:
  /console dd
  This command within a macro will toggle the addon's active state.
]]

_addon.name = 'DD'
_addon.version = '1.0'
_addon.author = 'Chriztian'
_addon.commands = {'dd'}

-- Default state is active
local active = true

-- Toggle the addon's activity
windower.register_event('addon command', function()
    active = not active
    windower.add_to_chat(207, 'DD Addon: ' .. (active and 'Activated' or 'Deactivated'))
end)

-- Checks incoming chat log messages
windower.register_event('incoming text', function(original, modified, mode)
    if not active then return end

    -- Check if the specific phrase is in the message with a wildcard for any preceding characters
    if original:match('.*Defense Down effect wears off.') then
        windower.send_command('input /p Defense Down effect wore off.')
    end
end)
