require('tables')
require('strings')
require('sets')
require('actions')

_addon.name = 'Arebati'
_addon.version = '1.0'
_addon.author = 'Chriztian'
_addon.commands = {'arebati', 'ab'}

local buff_spell_lists = {
    {Name='Haste', SpellID=57, CastTime=4},
    {Name='Protectra V', SpellID=129, CastTime=4},
	{Name='Shellra V', SpellID=134, CastTime=4},
	{Name='Barblizzara', SpellID=67, CastTime=3},
	{Name='Barparalyzra', SpellID=88, CastTime=6},
    {Name='Auspice', SpellID=96, CastTime=4},
    {Name='Boost-STR', SpellID=479, CastTime=6},
    --{Name='Reraise IV', SpellID=848, CastTime=8},
    --{Name='Aurorastorm', SpellID=119, CastTime=2},
    --{Name='Stoneskin', SpellID=54, CastTime=7},
    --{Name='Aquaveil', SpellID=55, CastTime=5},
    --{Name='Blink', SpellID=53, CastTime=6},

    -- Additional spells with their respective cast times can be added here
}

local casting = false
local current_spell_index = 1
local last_cast_time = 0

function cast_next_spell()
    if not casting or current_spell_index > #buff_spell_lists then
        casting = false
        current_spell_index = 1
        return
    end

    local current_time = os.clock()
    local spellInfo = buff_spell_lists[current_spell_index]
    if current_time - last_cast_time >= spellInfo.CastTime then
        windower.chat.input('/ma "'..spellInfo.Name..'" <me>')
        last_cast_time = current_time
        current_spell_index = current_spell_index + 1
    end
end

windower.register_event('addon command', function(...)
    local args = {...}
    if args[1]:lower() == 'buffs' then
        casting = true
        last_cast_time = os.clock() - buff_spell_lists[1].CastTime  -- Start immediately
        cast_next_spell()
    end
end)

windower.register_event('prerender', function()
    cast_next_spell()
end)
