_addon.name = 'Amps'
_addon.author = 'Chriztian'
_addon.version = '1.0'
_addon.commands = {'amps'}

require('logger')
extdata = require('extdata')
res_bags = require('resources').bags

local moogle_amp_id = 6608 -- Item ID for Moogle Amp.
local moogle_amp_buff_id = 629 -- Buff ID for Moogle Amplifier
local walk_of_echoes_zone_id = 298 -- Zone ID for Walk of Echoes [P1]
local check_interval = 60 -- Interval for checking the buff in seconds
local auto_check_enabled = true -- Flag to control automatic checking

local function use_moogle_amp(manual)
    if not auto_check_enabled and not manual then
        return
    end

    local buffs = windower.ffxi.get_player().buffs

    -- Check if Moogle Amp buff is already active
    for _, buff in ipairs(buffs) do
        if buff == moogle_amp_buff_id then
            log('Moogle Amplifier buff is already active.')
            return
        end
    end

    local item_array = {}
    local get_items = windower.ffxi.get_items

    -- Search for the Moogle Amp.
    for bag_id in pairs(res_bags:equippable(true)) do
        local bag = get_items(bag_id)
        for index, item in ipairs(bag) do
            if item.id == moogle_amp_id then
                item_array[item.id] = item
                item_array[item.id].bag = bag_id
                break
            end
        end
    end

    local item = item_array[moogle_amp_id]
    if item then
        log('Moogle Amp not active. Using Moogle Amp...')
        windower.chat.input('/item "Moogle Amp." <me>')
    else
        log('Moogle Amp not found in your inventory.')
    end
end

local function check_buff()
    if windower.ffxi.get_info().zone == walk_of_echoes_zone_id then
        use_moogle_amp(false)
    end
end

windower.register_event('addon command', function(command)
    command = command and command:lower() or 'on'

    if command == 'off' then
        auto_check_enabled = false
        log('Automatic checking disabled.')
    elseif command == 'on' then
        auto_check_enabled = true
        log('Automatic checking enabled.')
        check_buff()
    elseif command == 'use' then
        use_moogle_amp(true)
    end
end)

windower.register_event('zone change', function(new_id, old_id)
    if new_id == walk_of_echoes_zone_id then
        check_buff()
    end
end)

windower.register_event('load', function()
    check_buff()
end)

-- Coroutine to perform periodic checks
local function start_periodic_check()
    while true do
        coroutine.sleep(check_interval)
        check_buff()
    end
end

coroutine.schedule(start_periodic_check, check_interval)

log('Amps Script Loaded: Type //amps use to use Moogle Amp manually. Automatic checks in Walk of Echoes [P1]. Type //amps off to disable, //amps on to enable automatic checks.')
